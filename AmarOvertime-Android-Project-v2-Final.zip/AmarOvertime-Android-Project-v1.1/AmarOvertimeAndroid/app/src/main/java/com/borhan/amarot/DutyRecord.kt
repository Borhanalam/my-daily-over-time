package com.borhan.amarot.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "duty_records")
data class DutyRecord(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val date: String,          // Format: "YYYY-MM-DD" (যেমন: "2026-09-25")
    val monthYear: String,     // Format: "YYYY-MM" (যেমন: "2026-09")
    val shiftType: String,     // "DAY" অথবা "NIGHT"
    val startTime: String,     // "07:53 AM"
    val endTime: String,       // "12:11 AM"
    val regularHours: Double,  // ৮.০০
    val otHours: Double,       // ৭.১৮
    val totalHours: Double,    // ১৫.১৮
    val otWage: Double         // OT ঘণ্টার অর্জিত টাকা
)
